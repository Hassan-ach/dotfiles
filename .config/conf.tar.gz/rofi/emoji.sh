#!/usr/bin/env bash

rofimoji --selector-args="-theme ~/.config/rofi/themes/cat_chainsaw.rasi" --prompt "😀"
